var classOnlineMapsOSMNominatimResult =
[
    [ "OnlineMapsOSMNominatimResult", "classOnlineMapsOSMNominatimResult.html#aee06f3a0211d0bad153c0603827635ba", null ],
    [ "LoadAddressDetails", "classOnlineMapsOSMNominatimResult.html#a87557121fa1323e76d15b83647018134", null ],
    [ "addressdetails", "classOnlineMapsOSMNominatimResult.html#acc667460b1de1fd631dd6c9d33b12f63", null ],
    [ "boundingbox", "classOnlineMapsOSMNominatimResult.html#a1afdb089262c2a49876d1d6591ac88a3", null ],
    [ "display_name", "classOnlineMapsOSMNominatimResult.html#ae7865e48bc32161082db5a4676c8dcb4", null ],
    [ "importance", "classOnlineMapsOSMNominatimResult.html#a0d8f0c70d880dd8838cfea5d0079eb69", null ],
    [ "latitude", "classOnlineMapsOSMNominatimResult.html#a457bbdbf55e77933fc567b435c9c6c17", null ],
    [ "location", "classOnlineMapsOSMNominatimResult.html#a8c7f9f65b5a6c2700a0678d759c3feb2", null ],
    [ "longitude", "classOnlineMapsOSMNominatimResult.html#a98bc8f80d60cbca54fd35eac7f69d64a", null ],
    [ "node", "classOnlineMapsOSMNominatimResult.html#a925456ab532ef77ae4e16eaf4c13e79d", null ],
    [ "osm_id", "classOnlineMapsOSMNominatimResult.html#a150dba7185c13f6fd3f73807e5cbf112", null ],
    [ "osm_type", "classOnlineMapsOSMNominatimResult.html#ab09fea94045fc8652d4f525ad694a41a", null ],
    [ "place_id", "classOnlineMapsOSMNominatimResult.html#a98c614681f6c15ab6802ab2eac4a8857", null ],
    [ "place_rank", "classOnlineMapsOSMNominatimResult.html#a30c3ded8bd767a485e672ca022201866", null ],
    [ "type", "classOnlineMapsOSMNominatimResult.html#abd392ee34ea67d0703a275a5727cb49a", null ]
];