var classOnlineMapsBuildingBase =
[
    [ "OnlineMapsBuildingRoofType", "classOnlineMapsBuildingBase.html#a0a18912ebeb915f6e59fa6168c1f0d4b", [
      [ "dome", "classOnlineMapsBuildingBase.html#a0a18912ebeb915f6e59fa6168c1f0d4ba1b71c8e9e749753da4e8f55b029ced5f", null ],
      [ "flat", "classOnlineMapsBuildingBase.html#a0a18912ebeb915f6e59fa6168c1f0d4ba37fc7edee25a177474eaebe7f7b09785", null ]
    ] ],
    [ "Dispose", "classOnlineMapsBuildingBase.html#ad1b1ab2e19100fc908a0facf074c9682", null ],
    [ "LoadMeta", "classOnlineMapsBuildingBase.html#a382a6459e07c68214bbfd0ad7dc1bb2e", null ],
    [ "boundsCoords", "classOnlineMapsBuildingBase.html#a25d1fcd020ddd4522d3d24468a652298", null ],
    [ "centerCoordinates", "classOnlineMapsBuildingBase.html#a1f2356cdf9c4c97a5700d0e4cf9ab5ad", null ],
    [ "id", "classOnlineMapsBuildingBase.html#a60d10315ef64ffa4bf27b962fd962f8f", null ],
    [ "initialZoom", "classOnlineMapsBuildingBase.html#a3d9d370a481afe18db646f6dd10de60f", null ],
    [ "metaInfo", "classOnlineMapsBuildingBase.html#ae4b2f8f22f5bcbffd2d3dd26834cfbb9", null ],
    [ "OnClick", "classOnlineMapsBuildingBase.html#a4c8789cca999dbcfe10e380dc72536c1", null ],
    [ "OnDispose", "classOnlineMapsBuildingBase.html#aa91fc878c86cd3e4e2c6d32edb49e401", null ],
    [ "OnPress", "classOnlineMapsBuildingBase.html#afd8809536a3ea387dcf981b3e37258df", null ],
    [ "OnRelease", "classOnlineMapsBuildingBase.html#a6005b6ebef46767311131ee862dbb390", null ],
    [ "perimeter", "classOnlineMapsBuildingBase.html#a7ba0ff10f5592f5a98814abd2148e0d5", null ]
];