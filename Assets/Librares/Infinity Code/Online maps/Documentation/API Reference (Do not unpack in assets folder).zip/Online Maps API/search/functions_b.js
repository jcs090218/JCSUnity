var searchData=
[
  ['parseosmresponse',['ParseOSMResponse',['../classOnlineMapsOSMAPIQuery.html#a1b264f54addf426dcfab39ea4db2822f',1,'OnlineMapsOSMAPIQuery.ParseOSMResponse(string response, out List&lt; OnlineMapsOSMNode &gt; nodes, out List&lt; OnlineMapsOSMWay &gt; ways, out List&lt; OnlineMapsOSMRelation &gt; relations)'],['../classOnlineMapsOSMAPIQuery.html#aaf65869714d9c9014e17e0fe55e05c18',1,'OnlineMapsOSMAPIQuery.ParseOSMResponse(string response, out Dictionary&lt; string, OnlineMapsOSMNode &gt; nodes, out List&lt; OnlineMapsOSMWay &gt; ways, out List&lt; OnlineMapsOSMRelation &gt; relations)']]]
];
