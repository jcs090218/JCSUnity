var searchData=
[
  ['latlongtomercat',['LatLongToMercat',['../classOnlineMapsUtils.html#adc7ee11835e307baedd055edc442cb31',1,'OnlineMapsUtils.LatLongToMercat(float x, float y)'],['../classOnlineMapsUtils.html#a2aa8b939dd193460b5dc3643f1e0f794',1,'OnlineMapsUtils.LatLongToMercat(ref float x, ref float y)'],['../classOnlineMapsUtils.html#aff12b926b79a8da23d125231be7e9830',1,'OnlineMapsUtils.LatLongToMercat(ref double x, ref double y)']]],
  ['latlongtotile',['LatLongToTile',['../classOnlineMapsUtils.html#a2d56ea5a246ef4bb8daaaa6bb974a437',1,'OnlineMapsUtils.LatLongToTile(Vector2 p, int zoom)'],['../classOnlineMapsUtils.html#ad3b26d9863f9e7a044999d308554d837',1,'OnlineMapsUtils.LatLongToTile(double x, double y, int zoom)']]],
  ['latlongtotiled',['LatLongToTiled',['../classOnlineMapsUtils.html#ad3411efd804ca20ea187bed48f63dc0f',1,'OnlineMapsUtils']]],
  ['latlongtotilef',['LatLongToTilef',['../classOnlineMapsUtils.html#abb1092be43a6b357ecd9100c3bf2dd41',1,'OnlineMapsUtils.LatLongToTilef(Vector2 p, int zoom)'],['../classOnlineMapsUtils.html#a5610a28a61b1985158811ac1cb9db502',1,'OnlineMapsUtils.LatLongToTilef(Vector2 p, int zoom, out float fx, out float fy)'],['../classOnlineMapsUtils.html#a203aff4cd8e5a2feb1f559c0fc30a346',1,'OnlineMapsUtils.LatLongToTilef(float x, float y, int zoom)']]],
  ['load',['Load',['../classOnlineMapsXML.html#ac25e8443bc829254a7aac18a599fb30c',1,'OnlineMapsXML']]],
  ['loadaddressdetails',['LoadAddressDetails',['../classOnlineMapsOSMNominatimResult.html#a87557121fa1323e76d15b83647018134',1,'OnlineMapsOSMNominatimResult']]],
  ['loadmeta',['LoadMeta',['../classOnlineMapsBuildingBase.html#a382a6459e07c68214bbfd0ad7dc1bb2e',1,'OnlineMapsBuildingBase']]],
  ['looktocoordinates',['LookToCoordinates',['../classOnlineMapsMarker.html#a05ce40f70130f91f7a542155dc22b2c0',1,'OnlineMapsMarker.LookToCoordinates()'],['../classOnlineMapsMarker3D.html#a74fbc9bafec185ffa75ed2fb93efd233',1,'OnlineMapsMarker3D.LookToCoordinates()'],['../classOnlineMapsMarkerBase.html#a92d31913c11e266cb2501ea569db3a77',1,'OnlineMapsMarkerBase.LookToCoordinates()']]]
];
