var classOnlineMapsOSMRelationMember =
[
    [ "OnlineMapsOSMRelationMember", "classOnlineMapsOSMRelationMember.html#a20c5b82002ee26e64b786d4dd2c1fcca", null ],
    [ "reference", "classOnlineMapsOSMRelationMember.html#adcdab169db7377bb505c4545e980c030", null ],
    [ "role", "classOnlineMapsOSMRelationMember.html#abbf9dc4e2fbafcb4d5290ce3a6f4d040", null ],
    [ "type", "classOnlineMapsOSMRelationMember.html#ad31e7b8d52b35edb749698801e8a62c6", null ]
];