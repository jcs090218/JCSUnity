var classOnlineMapsFindPlaces =
[
    [ "OnlineMapsFindPlacesRankBy", "classOnlineMapsFindPlaces.html#a2e0eeba641497e789555ad2757efb2ba", [
      [ "prominence", "classOnlineMapsFindPlaces.html#a2e0eeba641497e789555ad2757efb2baaf7dcf4a2e0c2d8159278ed77934ddecc", null ],
      [ "distance", "classOnlineMapsFindPlaces.html#a2e0eeba641497e789555ad2757efb2baaa74ec9c5b6882f79e32a8fbd8da90c1b", null ]
    ] ],
    [ "OnlineMapsFindPlacesType", "classOnlineMapsFindPlaces.html#a0cc303c39fc627978c2b67ee105cc795", null ],
    [ "FindNearby", "classOnlineMapsFindPlaces.html#a59d39e4bbc5bfad56fa0487506e94d41", null ],
    [ "FindRadar", "classOnlineMapsFindPlaces.html#af485046a085c0980a52b0313c19a23a5", null ],
    [ "FindText", "classOnlineMapsFindPlaces.html#ad2292ca7e2063cf7437884adb83ca689", null ],
    [ "GetResults", "classOnlineMapsFindPlaces.html#ac54d2e47305ee8e29699cea089350d90", null ]
];