var classOnlineMapsOSMNode =
[
    [ "OnlineMapsOSMNode", "classOnlineMapsOSMNode.html#acc776c405849e2b3e192fbdf54bfe57c", null ],
    [ "lat", "classOnlineMapsOSMNode.html#ac8c18509e173a367f78854ae6a241422", null ],
    [ "lon", "classOnlineMapsOSMNode.html#a78c3af702b3998d3cd927d5a2861a14f", null ]
];