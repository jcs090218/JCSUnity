var classOnlineMapsBingMapsLocation =
[
    [ "FindByPoint", "classOnlineMapsBingMapsLocation.html#abf4a883c4b08305eec20fa45629109f7", null ],
    [ "FindByQuery", "classOnlineMapsBingMapsLocation.html#a2d0c1440278987b2f25d54915e70324a", null ],
    [ "GetResults", "classOnlineMapsBingMapsLocation.html#af976563a0b74e9ca8efe1b03929027ce", null ],
    [ "type", "classOnlineMapsBingMapsLocation.html#a64d2112affb480e9f846134d690ce622", null ]
];