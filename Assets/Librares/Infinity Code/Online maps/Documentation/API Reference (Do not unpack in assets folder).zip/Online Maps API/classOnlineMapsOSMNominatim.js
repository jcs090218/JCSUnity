var classOnlineMapsOSMNominatim =
[
    [ "GetResults", "classOnlineMapsOSMNominatim.html#a4421da68192acbe9444e70a11caf7901", null ],
    [ "Reverse", "classOnlineMapsOSMNominatim.html#acbad889792af7a055666bf34b5a5b4f0", null ],
    [ "Search", "classOnlineMapsOSMNominatim.html#a4d7dab9b2f22527c6486ce3e0a70befa", null ],
    [ "type", "classOnlineMapsOSMNominatim.html#a7b1276bf11797c9a07193f2860cf2edd", null ]
];