var classOnlineMapsBingMapsLocationResult =
[
    [ "OnlineMapsBingMapsLocationResult", "classOnlineMapsBingMapsLocationResult.html#a5df3f25a573968bb983d40a36478fc00", null ],
    [ "address", "classOnlineMapsBingMapsLocationResult.html#acd509528195ecd015b99618cb2c5a406", null ],
    [ "boundingBox", "classOnlineMapsBingMapsLocationResult.html#a51a69de822137dc2fa89518edbe8fbe3", null ],
    [ "confidence", "classOnlineMapsBingMapsLocationResult.html#a1e3323418f027ea6caaaa193cd07d7cb", null ],
    [ "entityType", "classOnlineMapsBingMapsLocationResult.html#a3d73a9a562c3220f8e76ca46d8bff542", null ],
    [ "formattedAddress", "classOnlineMapsBingMapsLocationResult.html#ae8e92b996e075ba95e02978bf1d9bd80", null ],
    [ "latitude", "classOnlineMapsBingMapsLocationResult.html#ab79e37b8c1003ee9c930788c6c2a6de1", null ],
    [ "location", "classOnlineMapsBingMapsLocationResult.html#af381a4e549961c125d31af081cd24200", null ],
    [ "longitude", "classOnlineMapsBingMapsLocationResult.html#ae9051fda32a449c299305d56ecccdfed", null ],
    [ "matchCode", "classOnlineMapsBingMapsLocationResult.html#afa82ae18efd9a72ad9733cdeec47a31f", null ],
    [ "name", "classOnlineMapsBingMapsLocationResult.html#a3151073d3ac75f23f0c6bb9c37906d10", null ],
    [ "node", "classOnlineMapsBingMapsLocationResult.html#a03b6669d4ec2710d5a3130f1fe37b520", null ]
];