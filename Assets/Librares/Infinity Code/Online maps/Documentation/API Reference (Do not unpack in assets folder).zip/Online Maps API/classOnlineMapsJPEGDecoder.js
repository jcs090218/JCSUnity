var classOnlineMapsJPEGDecoder =
[
    [ "GetColors", "classOnlineMapsJPEGDecoder.html#aa96ecb66b6d5aa4e93a65d589de7dd4b", null ]
];